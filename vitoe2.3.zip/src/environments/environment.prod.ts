export const environment = {
  production: true,
  apiUrl: 'http://api.mediastack.com/v1/',
  mediastackAccessKey: 'acafc51ecadd30af73a57fc450224ce3'
};
