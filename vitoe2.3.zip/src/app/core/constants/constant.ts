export const perPageItem = 20;
export const newsUrl = 'news';